# CodeIgniter 4 - Brazilian Portuguese (pt-BR) Language Localization

Localização de Linguagem no idioma Português Brasileiro para o CodeIgniter 4.

## Utilização:
Caminho até a pasta de alteração:
`app/Config/App.php`

Alterar o campo:
`public $defaultLocale = 'es';`

Para:
`public $defaultLocale = 'pt-br';`

Originalmente traduzido por [Natan Felles](https://github.com/natanfelles/CodeIgniter4-pt-BR).

---

 Desde que o framework ainda não foi lançado, algumas traduções poderão ter que ser atualizadas. 
- Versão atual: codeigniter 4.0.0-rc.3 released
