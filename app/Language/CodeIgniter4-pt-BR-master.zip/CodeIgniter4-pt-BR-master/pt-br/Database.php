<?php

return [
	'invalidEvent'         => '{0, string} não é um callback de Model Event válido.',
	'invalidArgument'      => 'Você deve fornecer um {0} válido.',
	'invalidAllowedFields' => 'Os campos permitidos devem ser especificados para o model: {0}',
	'emptyDataset'         => 'Não há dados para {0}.',
];
